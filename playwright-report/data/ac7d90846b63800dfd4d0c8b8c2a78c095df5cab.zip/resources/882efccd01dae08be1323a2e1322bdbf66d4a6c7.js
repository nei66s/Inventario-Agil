(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f0b0aed7._.js",
  "static/chunks/node_modules_lodash_b66f7c16._.js",
  "static/chunks/node_modules_recharts_es6_eb352055._.js",
  "static/chunks/node_modules_fa23dd4d._.js"
],
    source: "dynamic"
});
